document.getElementById('formulario').onsubmit = function(event){
    event.preventDefault();
};