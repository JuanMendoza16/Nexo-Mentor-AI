## Bienvenidos a nuestro sitio web NexoMentorAI 
	
Desarrollado por Juan Mendoza, Luciano Campos, Damian Orellana y Luz Huanca (v1.0.0.0)

![](/img/logo-nexo.svg)

---

## Índice: 

- Introducción
- Acceso
- Página principal
- Módulos
- Recursos
- LLM
- Resolución de problemas
- Glosario
- Contactanos

---

## Introducción:

El sitio desarrollado permitirá a alumnos, maestros e interesados en la tecnología a entender cómo se entrena un modelo de IA, desde la carga de un dataset hasta la visualización de métricas como precisión o pérdida.

El usuario podrá activar acciones simuladas, observar cómo cambian las métricas y aprender conceptos clave con explicaciones integradas.

---

## Acceso: 

Para entrar al sitio, el usuario necesitará crearse una cuenta con su correo electrónico y contraseña. Se puede acceder al sitio mediante el navegador Google Chrome.

---

## Página principal:

La página principal muestra el título de la misma e incluye muchas funciones, algunas de estas pueden estar y/o levar al usuario a otras páginas.

- Botón "Explorar Módulos": Lleva al usuario a la página de módulos tras un clic.
- Opción "MENÚ": Contiene las opciones "INICIO" y "MÓDULOS". Esta última cumple la misma función que el botón "Explorar Módulos" ya que también lleva a la página de módulos al hacer clic mientras que "INICIO" lleva a la página de inicio.
- Opción "EXPLORER": Misma función que la opción "MENÚ", pero tiene las opciones "LLM" y "RECURSOS". "RECURSOS" lleva al usuario a una página con diversos recursos como documentos y videos, cada uno con una breve descripción y un enlace a cada material. "LLM" es una página simuladora GPT que permite al usuario agregar texto para que el sitio lo simule.

![](/pages/landing.html)

---

## Página Módulos

Esta página contiene módulos de aprendizaje sobre LLM para el usuario, desde comprender los conceptos básicos de un LLM hasta simular para experimentar con el mismo.

![](/pages/modulos.html)

---

## Página Recursos

La página de recursos contiene material de estudio, aprendizaje y repaso sobre LLM para el usuario (documentos, simuladores y videos). Además, el usuario podrá filtrar los tipos de recursos para mayor comodidad, es decir, podrá marcar si quiere que su material sean, por ejemplo, solo videos o documentos.

![](/pages/recursos.html)

---

## Página LLM

Es un simulador GPT que permite al usuario ingresar texto para que la página lo simule después de que el usuario de clic en el botón "Simular".

![](/pages/llm.html)

---

## Resolución de problemas

¿Cómo recuperar acceso si no recibo el correo de confirmación?

Primero, revisa la carpeta de correo no deseado o spam, ya que a veces los correos automáticos pueden llegar allí. Si no encuentras el mensaje, intenta esperar unos minutos y solicita reenviar el correo de confirmación desde la página de acceso. Si después de esto aún no recibes el correo, comunícate con el soporte técnico usando la sección "Contáctanos" para que puedan ayudarte a activar tu cuenta manualmente.


¿Qué hacer si una página o módulo no carga correctamente?

Verifica que tu conexión a internet esté funcionando correctamente. Actualiza la página web presionando el botón de recarga o usando la tecla F5. Asegúrate de que estás usando el navegador Google Chrome, ya que es el recomendado para este sitio. Si el problema persiste, intenta borrar la caché y las cookies del navegador o prueba acceder en modo incógnito. Finalmente, si ninguna de estas opciones funciona, contacta al soporte indicando qué página o módulo presenta problemas para recibir ayuda.

¿Qué es un LLM y para qué sirve?

Un LLM (Large Language Model) es un sistema de inteligencia artificial diseñado para comprender y generar lenguaje humano de manera avanzada. Estos modelos pueden leer, interpretar y responder en lenguaje natural, facilitando tareas como la traducción, redacción automática, asistencia en escritura y diálogo conversacional. En nuestro sitio, el LLM se usa para que los usuarios puedan simular interacciones con una IA y entender cómo funcionan estos modelos en la práctica.

---

## Glosario 

Usuario: Persona que utiliza y/o trabaja con dispositivos (ej: celular, computadora, TV, tablet, chatbots, etc.)

![](/img/logo-usuario.png)

Módulo: 

LLM (Large Language Model): Sistema de IA que puede comprender y generar lenguaje humano.

Chatbot: Sitio web para realizar consultas a una Inteligencia Artificial (IA), ej: ChatGPT, Perplexity, DeepSeek, etc.

Navegador: App para acceder a internet, ej: Google Chrome, Internet Explorer y Microsoft Edge.